/** Host half of the plugin. Visible behavior is provided by the browser half. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map