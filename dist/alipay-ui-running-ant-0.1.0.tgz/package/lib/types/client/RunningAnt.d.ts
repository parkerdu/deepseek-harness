/** Animated running indicator rendered above the active conversation composer. */
import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Props supplied by the session-scoped input dock. */
export type RunningAntProps = PropsRuntime<'conversation.input.dock'>;
/** Render the crawler only while the current conversation is running. */
export declare function RunningAnt({ useSession }: RunningAntProps): import("react").JSX.Element | null;
//# sourceMappingURL=RunningAnt.d.ts.map