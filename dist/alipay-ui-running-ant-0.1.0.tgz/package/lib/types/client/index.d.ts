/** Browser plugin that contributes the running-ant indicator to the composer dock. */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
/** Required browser service for the input-dock contribution. */
export declare const inject: string[];
/** Register after the conversation package declares its session-scoped dock. */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map